def comparar_puntos(a, b):
    puntos_alice = 0
    puntos_bob = 0

    for i in range(3):
        if a[i] > b[i]:
            puntos_alice += 1
        elif a[i] < b[i]:
            puntos_bob += 1

    return puntos_alice, puntos_bob

# Entrada del usuario para las calificaciones de Alice
calificacion_alice = tuple(int(input(f"Ingrese la calificación de Alice para la categoría {i + 1}: ")) for i in range(3))

# Entrada del usuario para las calificaciones de Bob
calificacion_bob = tuple(int(input(f"Ingrese la calificación de Bob para la categoría {i + 1}: ")) for i in range(3))

# Calcular los puntos de comparación
alice_puntos, bob_puntos = comparar_puntos(calificacion_alice, calificacion_bob)

# Mostrar resultados
print(f"Puntos de Alice: {alice_puntos}")
print(f"Puntos de Bob: {bob_puntos}")