import re
from collections import Counter
import json

def contar_ocurrencias(texto):
    # Convertir todo el texto a minúsculas y eliminar puntuaciones
    texto = re.sub(r'[.,;]', '', texto.lower())
    
    # Dividir el texto en palabras
    palabras = texto.split()

    # Contar las ocurrencias de cada palabra
    conteo_palabras = Counter(palabras)

    # Convertir el resultado a un diccionario y luego a JSON
    resultado_json = json.dumps(conteo_palabras, indent=2)

    return resultado_json

# Ejemplo de uso
texto = input(f"Ingresa un texto a evaluar: ")
resultado = contar_ocurrencias(texto)
print(resultado)
